package pkgLaboratoire2;

public class CIDate {
    private int annee;
    private int mois;
    private int jour;

    // constructeurs
    public CIDate() {
        setAnnee(2024);
        setMois(01);
        setJour(01);

    }

    public CIDate(int annee, int mois, int jour) {
        setAnnee(annee);
        setMois(mois);
        setJour(jour);
    }

    // Accesseurs (get/lecture) , mutateur (set / ecriture)
    public int getAnnee() {
        return annee;
    }

    public int getMois() {
        return mois;
    }

    public int getJour() {
        return jour;
    }

    public void setAnnee(int annee) {
        this.annee = annee; // this juste pour distinguer le nom de param et le nom de l'attribut

    }

    public void setMois(int mois) {
        if (mois < 1) {
            this.mois = 1; // same qu'annee
        } else if (mois > 12) {
            this.mois = 12;
        } else {
            this.mois = mois;
        }
    }

    public void setJour(int jour) {
        switch (mois) {
            // Mois de 31 jours
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                if (jour >= 1 && jour <= 31) {
                    this.jour = jour;
                } else {
                    this.jour = 1;
                }
                break;
            // Mois de 30 jours
            case 4:
            case 6:
            case 9:
            case 11:
                if (jour >= 1 && jour <= 30) {
                    this.jour = jour;
                } else {
                    this.jour = 1;
                }
                // Fevrier
            case 2:
                int jourMax = 28;
                if (estBissextile()) {
                    jourMax = 29;
                    if (jour >= 1 && jour <= jourMax) {
                        this.jour = jour;
                    } else {
                        this.jour = 1;
                    }
                    break;

                }
            default:
                this.jour = 1;
                break;
        }
    }

    // private methode pour cette classe , non accessible par tout le monde
    private boolean estBissextile() {
        return (annee % 400 == 0) || (annee % 4 == 0 && annee % 100 != 0);
    }

}
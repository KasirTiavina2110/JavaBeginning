package pkgLaboratoire2;

import java.util.Random;

public class De {
    // Attributs
    private final int VALEURMIN;
    private final int VALEURMAX;
    private int valeur;

    // Constructeurs
    public De() {
        this.VALEURMIN = 1;
        this.VALEURMAX = 6;
    }

    public De(int valeurMin, int valeurMax, int valeur) {
        this.VALEURMAX = valeurMax;
        this.VALEURMIN = valeurMin;
        this.valeur = valeur;
    }

    public De(int valeur) {
        this.VALEURMIN = 1;
        this.VALEURMAX = 6;
        this.valeur = valeur;
    }

    // methode privees
    private boolean validerValeur(int valeur) {
        return valeur >= VALEURMIN && valeur <= VALEURMAX;
    }

    // get , set

    public int getVALEURMIN() {
        return VALEURMIN;
    }

    public int getVALEURMAX() {
        return VALEURMAX;
    }

    public int getValeur() {
        return valeur;
    }

    public void setValeur(int valeur) {
        if (validerValeur(valeur)) {
            this.valeur = valeur;
        } else {
            System.out.println("La valeur du dé doit être entre 1 et 6.");

        }
    }

    // methode publique
    public void lancerDe() {
        Random random = new Random();
        valeur = random.nextInt(VALEURMAX - VALEURMIN + 1) + VALEURMIN;
        if (valeur == 0) {
            valeur = 1;
        } else {
            valeur = random.nextInt(VALEURMAX - VALEURMIN + 1) + VALEURMIN;
        }
    }

    public String toString() {
        return "Valeur du dé : " + valeur;
    }

}

package pkgLaboratoire3;

import java.util.Objects;

/**
 * CIDate
 */
public class CIDate {
    private int annee;
    private int mois = 1;
    private int jour = 1;

    public CIDate() {
        setAnnee(2024);
        setMois(01);
        setJour(01);
    }

    public CIDate(int annee, int mois, int jour) {
        if (verifierDate(jour, mois, annee)) {
            setAnnee(annee);
            setMois(mois);
            setJour(jour);
        } else {
            throw new IllegalArgumentException("Date invalide");
        }
    }

    // Accesseurs (get/lecture) , mutateur (set / ecriture)
    public int getAnnee() {
        return annee;
    }

    public int getMois() {
        return mois;
    }

    public int getJour() {
        return jour;
    }

    public void setAnnee(int annee) {
        if (annee <= 1) {
            this.annee = 1;
        } else {
            this.annee = annee; // this juste pour distinguer le nom de param et le nom de l'attribut
        }
        setMois(this.mois);
        setJour(this.jour);
    }

    public void setMois(int mois) {
        if (mois <= 1) {
            this.mois = 1; // same qu'annee
        } else if (mois >= 12) {
            this.mois = 12;
        } else {
            this.mois = mois;
        }
        setJour(this.jour);
    }

    public void setJour(int jour) {
        switch (mois) {
            // Mois de 31 jours
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                if (jour >= 1 && jour <= 31) {
                    this.jour = jour;
                } else if(jour >= 31){
                    this.jour = 31;
                }else if( jour <= 1){
                    this.jour = 1;
                }else{
                    this.jour = jour;
                }
                break;
            // Mois de 30 jours
            case 4:
            case 6:
            case 9:
            case 11:
                if (jour >= 1 && jour <= 30) {
                    this.jour = jour;
                } else if(jour >= 30){
                    this.jour = 30;
                }else if( jour <= 1){
                    this.jour = 1;
                }else{
                    this.jour = jour;
                }
                // Fevrier
            case 2:
                int jourMax = 28;
                if (estBissextile()) {
                    System.out.println("L'annee est bissextile \n");
                    jourMax = 29;
                    if (jour >= 1 && jour <= jourMax) {
                        this.jour = jour;
                    } else {
                        this.jour = 1;
                    }
                    break;

                }
            default:
                this.jour = 1;
                break;
        }
        if (verifierDate(jour, this.mois, this.annee)) {
            this.jour = jour;
        } else {
            throw new IllegalArgumentException("Jour invalide");
        }
    }

    public String formatDate() {
        return String.format("%04d/%02d/%02d", annee, mois, jour);
    }

    // cette methode pour afficher jour, mois , annee
    @Override
    public String toString() {
        return "ClDate { " +
                "jour=" + jour +
                ", mois=" + mois +
                ", annee=" + annee +
                '}';
    }

    @Override
    public boolean equals(Object date) {
        if (this == date)
            return true;
        if (date == null || getClass() != date.getClass()) // date.getClass renvoie la classe associé
            return false;
        CIDate clDate = (CIDate) date; // si la date n'est pas conforme on la caste pour qu'il le soit
        return jour == clDate.jour &&
                mois == clDate.mois &&
                annee == clDate.annee;

        /*
         * on convertie (ou "caste") l'objet date en une
         * instance de la classe ClDate. Cela suppose que date est effectivement une
         * instance de ClDate ou d'une de ses sous-classes. Si date n'est pas une
         * instance de ClDate, une ClassCastException sera levée à l'exécution.
         * try {
         * CIDate clDate = (CIDate) date;
         * return jour == clDate.jour &&
         * mois == clDate.mois &&
         * annee == clDate.annee;
         * } catch (ClassCastException e) {
         * throw new
         * ClassCastException("L'objet passé en paramètre n'est pas une instance de CIDate."
         * );
         * }
         */
    }

    @Override
    public int hashCode() {
        return Objects.hash(jour, mois, annee);
    }

    // private methode pour cette classe , non accessible par tout le monde
    private boolean estBissextile() {
        return (annee % 400 == 0) || (annee % 4 == 0 && annee % 100 != 0);
    }

    private boolean verifierDate(int annee, int mois, int jour) {
        // Logique pour vérifier si la date est valide
        // Vous pouvez implémenter votre propre logique ici
        return true;
    }

    //
}
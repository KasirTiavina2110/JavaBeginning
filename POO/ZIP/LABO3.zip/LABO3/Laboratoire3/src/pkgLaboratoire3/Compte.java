package pkgLaboratoire3;

import java.util.Objects;

/**
 * Compte
 */
public class Compte {
    private double solde;
    private int numeroCompte;
    private String nomProprietaire;
    private CIDate dateOuverture;

    // Variables de classe
    private static int compteurNumerosCompte = 1;
    private static double tauxInteretAnnuel = 10;
    private static double fraisMensuels = 0.08;

    // Constructeurs
    public Compte() {
        this.numeroCompte = compteurNumerosCompte++;
        this.dateOuverture = new CIDate(); // Utilisation du constructeur par défaut de CIDate
        this.solde = 0.0;

    }

    public Compte( String nomProprietaire, int annee, int mois , int jour) {
        this(); //appelation du constructeur par defaut
        this.nomProprietaire = nomProprietaire;
        this.dateOuverture = new CIDate(annee, mois, jour);
    }

    // Méthodes d'accès pour les variables d'instance de classe
    public static double getTauxInteretAnnuel() {
        return tauxInteretAnnuel;
    }

    public static void setTauxInteretAnnuel(double taux) {
        tauxInteretAnnuel = taux;
    }

    public static double getFraisMensuels() {
        return fraisMensuels;
    }

    public static void setFraisMensuels(double frais) {
        fraisMensuels = frais;
    }

    // Méthodes d'accès pour les variables d'instance
    public int getNumeroCompte() {
        return numeroCompte;
    }

    public String getNomProprietaire() {
        return nomProprietaire;
    }

    public double getSolde() {
        return solde;
    }
    public CIDate getDateOuverture() {
        return dateOuverture;
    }

    // Méthode de service - Retrait
    public boolean retrait(double montant) {
        if (montant > 0 && solde - montant >= 0) {
            solde -= montant;
            return true;
        } else {
            return false;
        }
    }

    // Méthode de service - Dépôt
    public boolean depot(double montant) {
        if (montant > 0) {
            solde += montant;
            return true;
        } else {
            return false;
        }
    }

    // Méthode de service - Intérêt mensuel
    public void interet() {
        double interet = solde * (tauxInteretAnnuel / 12 / 100);
        solde += interet;
    }

    // Méthode de service - Frais mensuels
    public void frais() {
        solde -= (solde*fraisMensuels);
    }

    // Méthode equals
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Compte compte = (Compte) obj;
        return Double.compare(compte.solde, solde) == 0 &&
                numeroCompte == compte.numeroCompte &&
                nomProprietaire.equals(compte.nomProprietaire) &&
                dateOuverture.equals(compte.dateOuverture);
    }

    // Méthode hashCode
    @Override
    public int hashCode() {
        return Objects.hash(solde, numeroCompte, nomProprietaire, dateOuverture);
    }

    // Méthode toString
    @Override
    public String toString() {
        return "Compte{" +
                "solde=" + solde +
                ", numeroCompte=" + numeroCompte +
                ", nomProprietaire='" + nomProprietaire + '\'' +
                ", dateOuverture=" + dateOuverture +
                '}';
    }
    
}
package com.example;
// https://www.youtube.com/watch?v=zlHXH6maOR0 commencer un projet avec Maven
// https://www.youtube.com/watch?v=8-DRdDC_eIE Référence pour les Countries


public class CountryAPI 
{
    public static void main( String[] args ) {

        new MyFrame();

       
    }
}

package com.example;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.net.URL;

import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MyFrame extends JFrame implements ActionListener{ 
    
  
    JFrame frame = new JFrame();

    JButton button = new JButton();

    JTextField input = new JTextField();
    JTextField reception = new JTextField();

    JLabel label2 = new JLabel();
    JLabel informations = new JLabel();

    

    MyFrame(){
        
        //Frame

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setSize(500,500);
        frame.setVisible(true);
        frame.setTitle("Informations d'un pays");
        frame.add(button);
        frame.add(input);
        frame.add(label2);
        frame.add(informations);
        frame.add(reception);

        //Bouton

        button.setBounds(250,50,175,50);
        button.addActionListener(this);
        button.setText("Appuyer pour confirmer");
        button.setFocusable(false);

        // Texte

        label2.setText("Entrez un pays");
        label2.setBounds(124,27,120,50);

        informations.setText("Les informations sur le pays choisi ");
        informations.setBounds(130,100,350,50);

        //Input

        input.setSize(40, 15);
        input.setBounds(120, 64, 100, 30);

        reception.setSize(40,50);
        reception.setBounds(50,150,400,200);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== button){
            String saisie = input.getText();
            saisie = "https://restcountries.com/v3.1/name/" + saisie;
            try {
                @SuppressWarnings("deprecation")
                URL urlObj = new URL(saisie); //Aller chercher les informations sur internet
                HttpsURLConnection connection = (HttpsURLConnection) urlObj.openConnection();
                connection.setRequestMethod("GET"); //Send la request GET

                int responseCode = connection.getResponseCode();

                if(responseCode == HttpsURLConnection.HTTP_OK){ //Confirme que la réponse au site est bonne
                    StringBuilder sb = new StringBuilder(); //Permet de rendre des Strings Dynamiques 'mutable'
                    Scanner scanner = new Scanner(connection.getInputStream()); //GetInputStream -> Lire les données reçues
                    while (scanner.hasNext()) { //Tant qu'il y a des données ca return true
                        sb.append(scanner.nextLine());
                    }
                    ObjectMapper objectMapper = new ObjectMapper();
                    Country[] countries = objectMapper.readValue(String.valueOf(sb), new TypeReference<Country[]>() {});//TypeReference permet de garder l'objet en mémoire 
                    //readvalue transforme = JSON -­­> Java object
                    reception.setText(countries[0].toString());//Afficher les éléments dans le FieldTexte
                }
                else{
                    System.out.println("Erreur dans la GET request");
                }
            } catch (Exception error) {
                System.out.println(error);
            }
           
        }
    }





}


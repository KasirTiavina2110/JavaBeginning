import requests #python -m pip install requests
import json
import PySimpleGUI as sg #python -m pip install pysimplegui

#Créer les éléments du frame
layout = [  [sg.TabGroup([[
                sg.Tab('Envoyer la requête',[[sg.Text('Entrer le pays voulu'), sg.InputText(key=('-INPUT-'))]]),
                sg.Tab('Recevoir la requête',[[sg.Text('Voici les informations voulues'), sg.Multiline(size=(60,10), key=('-RCV-'))]])]])],
            [sg.Button('Envoyer'), sg.Button('Annuler')]

]

#Création du frame
frame = sg.Window('Exmeple API avec Python', layout)

while True:
    event, value = frame.read()
    if event == sg.WIN_CLOSED or event == 'Annuler': #Valeur de sortie si quitter ou annule
        break
    elif event == 'Envoyer':
        
        lien = "https://restcountries.com/v3.1/name/" + value['-INPUT-'] #On modifie le lien selon ce que l'utilisateur veut 

        response = requests.get(lien) #On envoit la requête au site
        sg.popup('Données ', value['-INPUT-'], "La valeur de la requête est :",response)
        data = response.json() #Tranforme les données en JSON
        try:
            continent = data[0]['continents']
            population = data[0]['population']
            monnaie = data[0]['currencies']
            capital = data[0]['capital']

            frame['-RCV-'].update(f"Le pays choisi : {value['-INPUT-']},\nil est sur le continent {continent},\nla capitale est {capital},\n il a une population de {population},\n"
                                  f"les informations sur la monnaie est la suivante : {monnaie}")
        except (IndexError, KeyError):
            sg.popup("Erreur quelque part")
            
frame.close() #Fermer la fenêtre lorsqu'on sort de la boucle


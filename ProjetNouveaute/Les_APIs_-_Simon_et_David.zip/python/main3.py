import requests
import json


pays = input("Vous voulez voir les informations de quel pays ? ")
lien = "https://restcountries.com/v3.1/name/" + pays #On modifie le lien selon ce que l'utilisateur veut 

response = requests.get(lien) #On envoit la requête au site
print(response.status_code)  #Nous donne le statut de la réponse
#print(response.json()) #Transformer en JSON

data = response.json()
try:
    continent = data[0]['continents']
    population = data[0]['population']
    monnaie = data[0]['currencies']

    monnaieSymbol = json.dumps(monnaie) #Convertir de dictionnaire à String

    print(f"Le pays choisi est le {pays}, le pays est situé sur le continent {continent}, la population est de {population} personnes.")
    print("L'information sur la monnaie est la suivante : " + monnaieSymbol)
except (IndexError, KeyError):
    print("Erreur quelque part")



    # e1yiJYMKakWJNBlCban1NDl1V8HklFwsZiShIP6PIVkvRJlTddmEVwsMbX3FBSldc6ijIWsjIzklxspYYk2xVku5cc21VKJrRxCkI964MQTPcrxSMKjlAdxqMQzecqxqMZilwUilT5GOlejeZNWY5NzWZ5UWRtlfcsGQxmvUexWb1KlnbzntRUW9ZaXtJPzgaiWH9PuZIKjDokxxLyCwJUOvYiWO1HlVRYmZlJy4cp3SQiiCOKiIJBTKalWb1qvAboiaI5sqIDk45ZhpbwWlVWMVYkXtN30wINjFo6iuUgHqJrhed1HERklWIFinwpivQ82l9et3c2G6FduieTSGIx6LI8izIGshI1kcNo1hcu3YREvDbQWaVDyWSRUeQLiJONifIVxvMMjucO3qNeC7Ims4IOkzRJhideGlVtJWct3pN01fZyW9Q6iAOLi6IkwANYCa8xw7MEiA8nysMwDzIi08IuiOwbimR6G8FE0zZwUuVO4Kc8GslryfZvXhMiipOpipIkw3NFCr8IwoMZi58LyrMYDHIc1gIFiRwxixRaWM1HhmaVWKxtBbZkGqRpyjZ6XbN6zmIXjqoFiZch2yl5tRb62u4gxxMd3sBkyoY6XARG0dZ3UtBCoWbl3aRrtnY1WplpsVLwm2NfvaboS1Ics0IJkXlhQ9QqWmRDkocgmyV9zqcYyCIN62IOjqYN56LbjlUWxPLyjCIS0bMLCJ40xkOpTXgUi6fqQA=a=i7796a1a524f1b02aea7bce8fd5504992f25945576490351640564e79e1853fe09ec6f2acc59c7111df1f0f00eb15a3520ead45abdef09a67e91d343246ae6ed76f255e067845603e9f450c9fd64b0238fe0ecd75fda14e14f29d2c68eb5343409530cb799864f18d246513c612d174464458d2be74aa7d43e24811b8e91d3da3e756a7c7611a1597e57cfaab7c1c2b04d09bbd76732bec87e4b34a7ebc40a7825d073561d8157ec8d2b7fad2018e43c524d26d0039308fdbd31b0fdf17f143c84ff1a0a06e48ff29fbd57202097ea77f1836a6895fb5ff0a42547318a64c12d0fb234b4c723769cfe20ebdb42235e244b52f612b5749ea9c51833587783ce723727f38aab9c8e194a69e5f1c6e7080b0daa809cc48795678767f832021fd37606bf759863691b2e5869485dc6ddf48d3b0ffbab54c61a6b76a1f9ce506b37948f3112b709d24d69064b67c03aab0dd44a1519d59919c16bba9bcc928fd00613e347d4ef0a88fc556e505eaec36c6afe66d6e7089be3764492f4973d3cdedc5d0be1d99ac13fa00cfe88ed95bac1276cbd977e4439043042808073d71ce3f1977066e8f17eb88b992083d61e47c780e959fdc9fe4e2a8c7292e1888da5ce045353a5e5b4c28d92abde2cc3ad94cc681e788f090065d96f8c55a25284e61568f5b3bed21d15c94315e0a17d49a54fac185b00d11ef34cd1a51c502f7acae50e2cf


package joueursHockey;
import java.util.regex.*;

public class Joueurs{


    private String nom;
    private String prenom;
    private int numero;
    private String equipe;
    private int age;
    


    public Joueurs(){

        nom="aucun";
        prenom="aucun";
        numero=0;
        age=0;
        
    }

    public Joueurs(String _nom, String _prenom, double _numero, double _age){

        setNom(_nom);
        setPrenom(_prenom);

    }


    public String getNom() {
        return nom;
    }


    public int getNumero() {
        return numero;
    }

    private int getAge() {
        return age;
    }



    public void setNom(String _nom) {
        if(validationNomEtPrenom(_nom)){

            this.nom = _nom;
        }   else{
            throw new IllegalArgumentException("Le nom n'est pas valide");
        }
           
        
    }

    public void setPrenom(String _prenom){
        if(validationNomEtPrenom(_prenom)){
            this.prenom = _prenom;
        }   else{
            throw new IllegalArgumentException("La prénom n'est pas valide");
        }
    }


    public void setAge(int _age){
        if(_age<0){
            System.out.println("L'age ne peut pas être négatif");
        }

        else{
            this.age = _age;
        }
    }

    private boolean validationNomEtPrenom(String nomPrenom){
        
        String regex = "^[A-Za-z]+$";
        Pattern patternNomEtPrenomValide = Pattern.compile(regex);
        Matcher matcher = patternNomEtPrenomValide.matcher(nomPrenom);   
        
        return matcher.matches();
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
    public void setEquipe( String _equipe){
        equipe = _equipe;
    }

public String toString() {
return "nom = "+nom+" , prenom = "+prenom+", numero = "+ numero+", age = "+age+"equipe = "+equipe;
}




    



    




    
}

package joueursHockey;

import javax.swing.JOptionPane;

public class testJoueurs {
public static void main(String[] args) {
    
    Joueurs unJoueur = new Joueurs();
    
    String prenom = JOptionPane.showInputDialog("Entrez le prénom du joueur");
    String nom = JOptionPane.showInputDialog("Entre le nom du joueur");
    String equipe = JOptionPane.showInputDialog("Entrez le nom de l'équipe");
    int age = Integer.parseInt(JOptionPane.showInputDialog("Entrez l'Age du joueur"));
    unJoueur.setPrenom(prenom);
    unJoueur.setNom(nom);
    unJoueur.setEquipe(equipe);
    unJoueur.setAge(age);

    System.out.println(unJoueur.toString());







}
}

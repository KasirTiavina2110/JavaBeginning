package pkgMagasin;
import java.util.LinkedList;

import pkgInterface.StructureDeDonneesFile;
import pkgInterface.StructureDeDonneesFileDequeue;


public class Deque<T> implements StructureDeDonneesFile<T>, StructureDeDonneesFileDequeue<T> {

    // Attributs
    private LinkedList<T> deque;

    // Constructeur

    public Deque() {
        deque = new LinkedList<>();
    }

   // Methodes

    public void insertFirst(T e) {
        deque.addFirst(e);
    }

   
    public void insertLast(T e) {
        deque.addLast(e);
    }

  
    public T removeFirst() {
        if (isEmpty()) {
            throw new IllegalStateException("La deque est vide.");
        }
        return deque.removeFirst();
    }

 
    public T removeLast() {
        if (isEmpty()) {
            throw new IllegalStateException("La deque est vide.");
        }
        return deque.removeLast();
    }

   
    public void enqueue(T element) {
        deque.addLast(element);
    }

   
    public T dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("La file est vide.");
        }
        return deque.removeFirst();
    }

    public T front() {
        if (isEmpty()) {
            throw new IllegalStateException("La file est vide.");
        }
        return deque.getFirst();
    }

    
    public int size() {
        return deque.size();
    }

    
    public boolean isEmpty() {
        return deque.isEmpty();
    }

    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < deque.size(); i++) {
            sb.append(deque.get(i)).append("\n");
        }
        return sb.toString();
    }

}
